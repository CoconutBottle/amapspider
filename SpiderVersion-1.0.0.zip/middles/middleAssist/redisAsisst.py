#-*- coding: UTF-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
currentUrl = os.path.dirname(__file__)
parentUrl = os.path.abspath(os.path.join(currentUrl, os.pardir))
sys.path.append(parentUrl)

import redis
from settings import RedisHost


class imredis(object):
    def __init__(self):
        self.host = RedisHost["host"]
        self.port = RedisHost["port"]
        self.pw = RedisHost["passwd"]
        self.db = RedisHost["db"]

    def setVar(self, host="127.0.0.1", port=6379, pw=""):
        self.host = host
        self.port = port
        self.pw = pw

    def connection(self):
        return redis.Redis(host=self.host,
                           port=self.port,
                           password=self.pw,
                           db=self.db)

    def __del__(self):
        del self


