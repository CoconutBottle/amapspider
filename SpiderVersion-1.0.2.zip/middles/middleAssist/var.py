var = [
{'account':['15626404846',
'z20180517!'],
'cookie':{'UM_distinctid':'1667fd1f2c439b-02718094f0fc62-43450521-1fa400-1667fd1f2c51e7; ',
'_ga':'GA1.2.66068986.1539742758; ',
'cloud-anonymous-token':'233be42c12f349a6aa0c3e12c4c9eabf; ', '_gid':'GA1.2.374061592.1541382800; ',
'_gat':'1; '}}
,

{'account':['18100226031',
'z20180517!'],
'cookie':{'UM_distinctid':'1667fd1f2c439b-02718094f0fc62-43450521-1fa400-1667fd1f2c51e7; ',
'_ga':'GA1.2.66068986.1539742758; ',
'cloud-anonymous-token':'233be42c12f349a6aa0c3e12c4c9eabf; ', '_gid':'GA1.2.374061592.1541382800; ',
'_gat':'1; '}}
,

{'account':['13726566433',
'z20180517!'],
'cookie':{'UM_distinctid':'1667fd1f2c439b-02718094f0fc62-43450521-1fa400-1667fd1f2c51e7; ',
'_ga':'GA1.2.66068986.1539742758; ',
'cloud-anonymous-token':'233be42c12f349a6aa0c3e12c4c9eabf; ',
'_gid':'GA1.2.374061592.1541382800; ',
"_gat": "1"
}}

,
{'account':['15625101406',
'$a123456789'],
'cookie':{"cloud-anonymous-token":"233be42c12f349a6aa0c3e12c4c9eabf; ",
"UM_distinctid": "1667fd1f2c439b-02718094f0fc62-43450521-1fa400-1667fd1f2c51e7; ",
"_ga": "GA1.2.66068986.1539742758; ",
"_gid": "GA1.2.2074228101.1541142296; ",
"_gat": "1"}}

,

{'account':['15521057661',
'123456@As'],
'cookie':{'UM_distinctid':'1667fd1f2c439b-02718094f0fc62-43450521-1fa400-1667fd1f2c51e7; ',
'_ga':'GA1.2.66068986.1539742758; ',
'cloud-anonymous-token':'233be42c12f349a6aa0c3e12c4c9eabf; ', '_gid':'GA1.2.374061592.1541382800; ',
'_gat':'1; '}}]